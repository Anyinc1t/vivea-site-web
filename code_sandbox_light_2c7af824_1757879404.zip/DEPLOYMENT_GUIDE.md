# Guide de Déploiement - Vivéa Site Web

## 🚨 Problème: Formulaire et Base de Données

### Pourquoi le formulaire ne fonctionne pas sur le site publié ?

Quand vous développez localement, vous avez accès à l'**API RESTful de développement** (`/tables`). Mais une fois le site **publié sur un hébergement statique**, cette API n'est plus disponible.

## ✅ Solutions Implémentées

### 1. **Détection automatique d'environnement**
Le site détecte automatiquement s'il est en développement ou en production et adapte son comportement.

### 2. **Service Email Externe (Recommandé)**

#### Option A: Formspree (Gratuit)
1. Aller sur [formspree.io](https://formspree.io)
2. Créer un compte gratuit
3. Créer un nouveau formulaire
4. Copier l'ID du formulaire
5. Modifier le fichier `js/form-handler.js` ligne 82 :
```javascript
formspree: {
    endpoint: 'https://formspree.io/f/VOTRE_FORM_ID_ICI'
}
```

#### Option B: Netlify Forms (Si hébergé sur Netlify)
Si vous hébergez sur Netlify, ajoutez `netlify` à l'élément form dans `index.html` :
```html
<form class="cta-form" netlify>
```

### 3. **Fallback Email (Automatique)**
Si les services externes échouent, le site ouvrira automatiquement le client email par défaut avec les informations pré-remplies.

## 📧 Configuration Email

### Modifier l'adresse de contact
Dans `js/form-handler.js`, ligne 175 :
```javascript
contact: {
    email: 'contact@vivea.ca',  // ⬅️ Modifier ici
    phone: '1-800-VIVEA-1'      // ⬅️ Modifier ici
}
```

## 🔧 Instructions de Configuration

### Étape 1: Choisir votre solution email

**Pour Formspree (Recommandé - Gratuit) :**

1. **Créer un compte** sur [formspree.io](https://formspree.io)
2. **Créer un formulaire** et noter l'ID (ex: `xwpejrbo`)
3. **Modifier** `js/form-handler.js` ligne 82 :
```javascript
endpoint: 'https://formspree.io/f/xwpejrbo'  // Remplacer par votre ID
```

**Pour EmailJS (Alternative) :**
- Plus complexe mais plus personnalisable
- Requiert configuration API

### Étape 2: Tester avant publication

1. **Tester en local** : Le formulaire utilisera l'API de développement
2. **Tester en production** : Le formulaire utilisera le service email configuré

### Étape 3: Publier

Utilisez l'**onglet Publish** pour déployer le site avec la nouvelle configuration.

## 🔍 Vérification Post-Déploiement

### Comment vérifier que ça fonctionne :

1. **Aller sur le site publié**
2. **Remplir le formulaire** de test d'eau
3. **Soumettre** - Vous devriez voir :
   - Message de confirmation avec numéro de suivi
   - Email reçu via Formspree (si configuré)
   - OU ouverture du client email (fallback)

### En cas de problème :

1. **Ouvrir la console** du navigateur (F12)
2. **Chercher les messages** d'erreur
3. **Vérifier** que l'ID Formspree est correct
4. **Tester** le fallback email

## 💾 Sauvegarde Locale

Le site sauvegarde automatiquement toutes les demandes dans le navigateur comme backup, même si l'envoi email échoue.

**Pour récupérer les demandes sauvegardées :**
```javascript
// Dans la console du navigateur
console.log(JSON.parse(localStorage.getItem('vivea_requests') || '[]'));
```

## 📊 Base de Données en Production

### Pour une vraie base de données en production, vous devriez :

1. **Utiliser un service backend** comme :
   - Supabase (PostgreSQL gratuit)
   - Firebase (Google)
   - Airtable (feuille de calcul comme DB)

2. **Ou intégrer avec un CRM** comme :
   - HubSpot
   - Pipedrive
   - Salesforce

3. **Webhook Formspree** : Formspree peut envoyer les données vers votre système via webhook

## 🚀 Prochaines Étapes Recommandées

### Immédiat :
1. ✅ Configurer Formspree
2. ✅ Tester le formulaire
3. ✅ Publier le site

### Court terme :
1. 📊 Intégrer avec un CRM
2. 📧 Configurer l'email automatique de confirmation
3. 📞 Ajouter un système de prise de rendez-vous

### Long terme :
1. 🗄️ Base de données complète
2. 🔐 Espace client
3. 📈 Analytics avancés

---

## ⚡ Solution Rapide (5 minutes)

1. **Aller sur** [formspree.io](https://formspree.io)
2. **S'inscrire** (gratuit)
3. **Créer un formulaire**
4. **Copier l'ID** (ex: `xwpejrbo`)
5. **Modifier** `js/form-handler.js` ligne 82
6. **Publier** via l'onglet Publish

✅ **Votre formulaire fonctionnera en production !**