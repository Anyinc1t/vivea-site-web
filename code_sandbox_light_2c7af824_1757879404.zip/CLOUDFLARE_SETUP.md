# 🌐 Configuration Cloudflare Pages pour Vivéa

## 🚀 Déploiement sur Cloudflare Pages

### Étape 1: Préparer le Code

✅ **Fichiers ajoutés pour Cloudflare :**
- `functions/submit-form.js` - Fonction serverless pour traiter le formulaire
- `_redirects` - Règles de redirection
- `wrangler.toml` - Configuration Cloudflare
- `CLOUDFLARE_SETUP.md` - Ce guide

### Étape 2: Créer le Projet sur Cloudflare Pages

1. **Aller sur** [dash.cloudflare.com](https://dash.cloudflare.com)
2. **Pages** → **Créer un projet**
3. **Connecter Git** (GitHub, GitLab, etc.)
4. **Sélectionner** votre repository Vivéa
5. **Paramètres de build :**
   ```
   Framework preset: None
   Build command: (laisser vide)
   Build output directory: /
   Root directory: /
   ```
6. **Déployer**

### Étape 3: Configurer les Variables d'Environnement

Dans **Cloudflare Pages** → **Paramètres** → **Variables d'environnement** :

#### Variables Obligatoires :
```bash
CONTACT_EMAIL = contact@vivea.ca
FROM_EMAIL = noreply@vivea.ca
```

#### Service Email (Choisir UNE option) :

**Option A: Resend.com (Recommandé)**
```bash
RESEND_API_KEY = re_VOTRE_CLE_API_ICI
```

**Option B: SendGrid**
```bash
SENDGRID_API_KEY = SG.VOTRE_CLE_API_ICI
```

### Étape 4: Configurer un Service Email

#### 🎯 **Option A: Resend.com (Recommandé - Gratuit)**

1. **S'inscrire** sur [resend.com](https://resend.com)
2. **Vérifier** votre domaine email
3. **Créer une API Key**
4. **Ajouter** `RESEND_API_KEY` dans Cloudflare Pages
5. **Modifier** `CONTACT_EMAIL` et `FROM_EMAIL`

#### 📧 **Option B: SendGrid**

1. **S'inscrire** sur [sendgrid.com](https://sendgrid.com)
2. **Créer une API Key**
3. **Vérifier** votre domaine email
4. **Ajouter** `SENDGRID_API_KEY` dans Cloudflare Pages

### Étape 5: (Optionnel) Stockage des Données

Pour sauvegarder les demandes dans Cloudflare KV :

1. **Workers & Pages** → **KV**
2. **Créer un namespace** : `VIVEA_REQUESTS`
3. **Lier au projet Pages** :
   - **Paramètres** → **Functions**
   - **KV namespace bindings**
   - **Variable name :** `VIVEA_KV`
   - **KV namespace :** `VIVEA_REQUESTS`

## 🔧 Fonctionnalités du Système

### ✅ **Ce que fait la fonction Cloudflare :**

1. **Reçoit** les données du formulaire
2. **Valide** les informations (email, téléphone, etc.)
3. **Génère** un ID de suivi unique
4. **Envoie** un email formaté professionnel
5. **Sauvegarde** dans KV (optionnel)
6. **Retourne** une confirmation avec ID de suivi

### 📧 **Email automatique envoyé :**

- **Objet :** `Nouvelle demande de test d'eau - VIV-XXX-XXX`
- **Format HTML** professionnel avec logo Vivéa
- **Informations complètes** du prospect
- **Boutons d'action** (Appeler, Email)
- **ID de suivi** pour follow-up

### 🔒 **Sécurité incluse :**

- **Validation** des données côté serveur
- **Protection CORS** configurée
- **Rate limiting** par IP (Cloudflare)
- **Sanitisation** des données

## 🧪 Test du Formulaire

### Test en Local (Développement) :
```bash
# Si vous avez wrangler installé
npm install -g wrangler
wrangler pages dev
```

### Test en Production :
1. **Déployer** sur Cloudflare Pages
2. **Aller** sur votre site `votre-site.pages.dev`
3. **Remplir** le formulaire de test
4. **Vérifier** l'email reçu
5. **Confirmer** l'ID de suivi généré

## 🚨 Dépannage

### **Formulaire ne fonctionne pas :**
1. **Vérifier** les variables d'environnement
2. **Contrôler** les logs Cloudflare Pages
3. **Tester** l'API email séparément
4. **Confirmer** la configuration CORS

### **Email non reçu :**
1. **Vérifier** le domaine email (expéditeur)
2. **Contrôler** les quotas API (Resend/SendGrid)
3. **Checker** les dossiers spam
4. **Valider** la clé API

### **Erreur 500 :**
1. **Voir** les logs dans Functions → Logs
2. **Vérifier** la syntaxe du code
3. **Confirmer** les variables d'environnement
4. **Tester** avec des données simples

## 📊 Monitoring

### **Logs disponibles :**
- **Pages** → **Functions** → **Logs**
- **Analytics** → **Web Analytics**
- **Email delivery** dans Resend/SendGrid

### **Métriques importantes :**
- Taux de conversion formulaire
- Emails envoyés/livrés
- Erreurs serveur
- Temps de réponse

## 🔄 Mises à jour

Pour mettre à jour le site :
1. **Pusher** les changements sur Git
2. **Cloudflare Pages** redéploie automatiquement
3. **Tester** le formulaire après déploiement

## ⚡ Avantages Cloudflare Pages

✅ **Gratuit** jusqu'à 100,000 requêtes/mois  
✅ **Rapide** - Edge computing mondial  
✅ **Sécurisé** - HTTPS automatique  
✅ **Scalable** - Gestion automatique du trafic  
✅ **Intégré** - Git, DNS, CDN inclus  
✅ **Functions** - Serverless sans configuration  

---

## 🎯 Résumé - Action Immédiate

1. ✅ **Déployer** sur Cloudflare Pages
2. ✅ **Configurer** Resend.com (5 min)
3. ✅ **Ajouter** les variables d'environnement
4. ✅ **Tester** le formulaire
5. ✅ **Formulaire fonctionnel** ! 🎉

**Votre site Vivéa sera en ligne avec un formulaire professionnel qui fonctionne parfaitement !**